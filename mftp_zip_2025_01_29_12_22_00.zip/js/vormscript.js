function lugemine(){
    document.getElementById("vastus").innerHTML= "Tere hommikust, "+document.getElementById("nimi").value+" "+document.getElementById("pnimi").value;
}
//sama funktsioon koos muutujatega
function lugemine2(){
    let nimi=document.getElementById("nimi").value;
    let pnimi=document.getElementById("pnimi").value;
    let vastus=document.getElementById("vastus");
    let varv=document.getElementById("varv");
    //radio-nupud
    let mees=document.getElementById("mees");
    let naine=document.getElementById("naine");
    let synnipaev=document.getElementById("synnipaev").value;

    let number=document.getElementById("number").value;
    let email=document.getElementById("email").value;
    let tel=document.getElementById("tel").value;
    let url=document.getElementById("url").value;


    if(mees.checked){
        vastus.innerHTML= "Tere hommikust, mees "+nimi+" "+pnimi+"!"+" Sinu sünnipäev on "+synnipaev;
        vastus.style.color=varv.value;
    } else if(naine.checked) {
        vastus.innerHTML= "Tere hommikust, naine "+nimi+" "+pnimi+"!"+" Sinu sünnipäev on "+synnipaev;
        vastus.style.color=varv.value;
    } else {
        vastus.innerHTML="palun vali sugu";
    }
    document.getElementById("vastus").innerHTML= "Tere hommikust, "+document.getElementById("nimi").value+" "+document.getElementById("pnimi").value+" "+
    "Sinu number: " + document.getElementById("number").value + ".<br>" + 
    "Sinu tel: " + document.getElementById("tel").value + ".<br>" + 
    "Sinu email: " + document.getElementById("email").value + ".<br>"+
    "Sinu url: " + document.getElementById("url").value + ".";
}